If you are going to change the code, its recommenced to fork the source code in github (see below) for making the changes more accessible.

github repository: https://github.com/amiraliakbari/korsi

